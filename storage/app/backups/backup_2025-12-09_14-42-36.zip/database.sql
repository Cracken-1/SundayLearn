-- SundayLearn Database Backup
-- Generated on: 2025-12-09 14:42:36

-- Table: admin_activities
DROP TABLE IF EXISTS `admin_activities`;
CREATE TABLE `admin_activities` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action` varchar(100) NOT NULL COMMENT 'created, updated, deleted, published',
  `model_type` varchar(255) DEFAULT NULL COMMENT 'Model class name',
  `model_id` bigint(20) DEFAULT NULL COMMENT 'Model record ID',
  `description` text NOT NULL COMMENT 'Activity description',
  `properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Additional data' CHECK (json_valid(`properties`)),
  `ip_address` varchar(45) DEFAULT NULL COMMENT 'User IP address',
  `user_agent` text DEFAULT NULL COMMENT 'User agent string',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_admin_activities_model` (`model_type`,`model_id`),
  KEY `idx_admin_activities_action` (`action`),
  KEY `idx_admin_activities_created_at` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Admin activity log';

-- Table: admin_users
DROP TABLE IF EXISTS `admin_users`;
CREATE TABLE `admin_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) DEFAULT 'admin' COMMENT 'super_admin, admin, editor',
  `is_active` tinyint(1) DEFAULT 1,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_admin_users_email` (`email`),
  KEY `idx_admin_users_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Admin user accounts';

-- Data for table: admin_users
INSERT INTO `admin_users` VALUES ('1', 'Admin User', 'admin@sundaylearn.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'super_admin', '1', NULL, NULL, '2025-12-09 14:36:40', '2025-12-09 14:36:40');

-- Table: blog_posts
DROP TABLE IF EXISTS `blog_posts`;
CREATE TABLE `blog_posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `excerpt` text DEFAULT NULL COMMENT 'Short description',
  `content` longtext NOT NULL COMMENT 'Blog post content',
  `author` varchar(255) DEFAULT NULL COMMENT 'Author name',
  `image_url` varchar(500) DEFAULT NULL COMMENT 'Featured image path',
  `category` varchar(100) DEFAULT NULL COMMENT 'Blog category',
  `tags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Tags array' CHECK (json_valid(`tags`)),
  `meta_title` varchar(255) DEFAULT NULL COMMENT 'SEO meta title',
  `meta_description` text DEFAULT NULL COMMENT 'SEO meta description',
  `is_featured` tinyint(1) DEFAULT 0 COMMENT 'Featured post flag',
  `views_count` int(11) DEFAULT 0 COMMENT 'Number of views',
  `status` varchar(50) DEFAULT 'draft' COMMENT 'draft, published',
  `published_at` timestamp NULL DEFAULT NULL COMMENT 'Publication date',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_blog_posts_slug` (`slug`),
  KEY `idx_blog_posts_status` (`status`),
  KEY `idx_blog_posts_category` (`category`),
  KEY `idx_blog_posts_published_at` (`published_at`),
  KEY `idx_blog_posts_is_featured` (`is_featured`),
  FULLTEXT KEY `idx_blog_posts_search` (`title`,`content`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Blog posts';

-- Table: lessons
DROP TABLE IF EXISTS `lessons`;
CREATE TABLE `lessons` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `excerpt` text DEFAULT NULL COMMENT 'Short description',
  `scripture` varchar(255) DEFAULT NULL COMMENT 'Bible reference',
  `theme` varchar(255) DEFAULT NULL COMMENT 'Lesson theme',
  `age_group` varchar(255) DEFAULT NULL COMMENT 'Target age group',
  `duration` int(11) DEFAULT NULL COMMENT 'Duration in minutes',
  `thumbnail` varchar(500) DEFAULT NULL COMMENT 'Thumbnail image path',
  `image_url` varchar(500) DEFAULT NULL COMMENT 'Featured image path',
  `overview` text DEFAULT NULL COMMENT 'Lesson overview',
  `objectives` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Learning objectives array' CHECK (json_valid(`objectives`)),
  `content` longtext NOT NULL COMMENT 'Main lesson content',
  `discussion_questions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Discussion questions array' CHECK (json_valid(`discussion_questions`)),
  `video_url` varchar(500) DEFAULT NULL COMMENT 'YouTube/Vimeo URL',
  `audio_url` varchar(500) DEFAULT NULL COMMENT 'Audio file URL',
  `downloads` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Downloadable resources' CHECK (json_valid(`downloads`)),
  `attachments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'File attachments (PDF, DOC, etc)' CHECK (json_valid(`attachments`)),
  `category` varchar(100) DEFAULT NULL COMMENT 'Lesson category',
  `difficulty` varchar(50) DEFAULT NULL COMMENT 'beginner, intermediate, advanced',
  `order` int(11) DEFAULT 0 COMMENT 'Display order',
  `tags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Tags array' CHECK (json_valid(`tags`)),
  `meta_title` varchar(255) DEFAULT NULL COMMENT 'SEO meta title',
  `meta_description` text DEFAULT NULL COMMENT 'SEO meta description',
  `is_featured` tinyint(1) DEFAULT 0 COMMENT 'Featured lesson flag',
  `views_count` int(11) DEFAULT 0 COMMENT 'Number of views',
  `last_viewed_at` timestamp NULL DEFAULT NULL COMMENT 'Last view timestamp',
  `status` varchar(50) DEFAULT 'draft' COMMENT 'draft, published',
  `published_at` timestamp NULL DEFAULT NULL COMMENT 'Publication date',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_lessons_slug` (`slug`),
  KEY `idx_lessons_status` (`status`),
  KEY `idx_lessons_category` (`category`),
  KEY `idx_lessons_difficulty` (`difficulty`),
  KEY `idx_lessons_published_at` (`published_at`),
  KEY `idx_lessons_is_featured` (`is_featured`),
  KEY `idx_lessons_age_group` (`age_group`),
  FULLTEXT KEY `idx_lessons_search` (`title`,`content`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Sunday School lessons';

-- Table: migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Laravel migrations';

-- Data for table: migrations
INSERT INTO `migrations` VALUES ('1', '2024_12_06_000001_create_telegram_raw_imports_table', '1');
INSERT INTO `migrations` VALUES ('2', '2024_12_08_000001_add_attachments_to_lessons_table', '1');
INSERT INTO `migrations` VALUES ('3', '2024_12_08_000002_create_admin_activities_table', '1');
INSERT INTO `migrations` VALUES ('4', '2019_12_14_000001_create_personal_access_tokens_table', '2');
INSERT INTO `migrations` VALUES ('5', '2024_01_01_000001_create_users_table', '2');
INSERT INTO `migrations` VALUES ('6', '2025_12_09_131322_add_lesson_id_to_telegram_raw_imports_table', '3');

-- Table: personal_access_tokens
DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: telegram_raw_imports
DROP TABLE IF EXISTS `telegram_raw_imports`;
CREATE TABLE `telegram_raw_imports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `telegram_message_id` bigint(20) DEFAULT NULL COMMENT 'Telegram message ID',
  `chat_id` bigint(20) DEFAULT NULL COMMENT 'Telegram chat ID',
  `user_id` bigint(20) DEFAULT NULL COMMENT 'Telegram user ID',
  `username` varchar(255) DEFAULT NULL COMMENT 'Telegram username',
  `message_type` varchar(50) DEFAULT NULL COMMENT 'text, photo, video, document',
  `text_content` text DEFAULT NULL COMMENT 'Message text',
  `caption` text DEFAULT NULL COMMENT 'Media caption',
  `media_type` varchar(50) DEFAULT NULL COMMENT 'photo, video, audio, document',
  `file_id` varchar(500) DEFAULT NULL COMMENT 'Telegram file ID',
  `file_unique_id` varchar(500) DEFAULT NULL COMMENT 'Telegram unique file ID',
  `file_path` varchar(500) DEFAULT NULL COMMENT 'Downloaded file path',
  `file_size` bigint(20) DEFAULT NULL COMMENT 'File size in bytes',
  `mime_type` varchar(100) DEFAULT NULL COMMENT 'File MIME type',
  `media_group_id` varchar(255) DEFAULT NULL COMMENT 'Media group ID for albums',
  `raw_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Complete Telegram update JSON' CHECK (json_valid(`raw_data`)),
  `processing_status` varchar(50) DEFAULT 'pending' COMMENT 'pending, processing, completed, failed',
  `processed_at` timestamp NULL DEFAULT NULL COMMENT 'Processing completion time',
  `error_message` text DEFAULT NULL COMMENT 'Error message if failed',
  `lesson_id` bigint(20) unsigned DEFAULT NULL,
  `created_lesson_id` bigint(20) DEFAULT NULL COMMENT 'Created lesson ID',
  `created_blog_id` bigint(20) DEFAULT NULL COMMENT 'Created blog post ID',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_telegram_imports_status` (`processing_status`),
  KEY `idx_telegram_imports_message_id` (`telegram_message_id`),
  KEY `idx_telegram_imports_media_group` (`media_group_id`),
  KEY `idx_telegram_imports_created_at` (`created_at`),
  KEY `idx_telegram_imports_user_id` (`user_id`),
  KEY `telegram_raw_imports_lesson_id_foreign` (`lesson_id`),
  CONSTRAINT `telegram_raw_imports_lesson_id_foreign` FOREIGN KEY (`lesson_id`) REFERENCES `lessons` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Telegram bot imports';

-- Table: users
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'viewer',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

